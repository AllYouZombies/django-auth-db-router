=====
Asakabank Risk Assessment backend SDK
=====

Our first implementation of custom SDK

Quick start
-----------

1. Add "abra_sdk" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'abra_sdk',
        ...
    ]


2. Next steps will be explained when we understand them =)